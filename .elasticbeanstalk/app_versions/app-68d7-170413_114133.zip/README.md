image-of-the-day
================

Example application for beanstalk deployment blog
